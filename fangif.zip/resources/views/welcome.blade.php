@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-sm-4">
            <H1>HOLA copaamerica</H1>
        </div>
        <div class="col-sm-4">
            <H1>HOLA copaamerica</H1>
        </div>
    </div>
</div>
@endsection
